#include "../../munit/munit.h"

MunitSuite* simde_tests_arm_neon_get_suite(void);
