#include "../../munit/munit.h"

MunitSuite* simde_tests_mips_msa_simd_get_suite(void);
